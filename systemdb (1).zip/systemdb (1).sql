-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2025 at 04:50 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_requests`
--

CREATE TABLE `booking_requests` (
  `id` int(11) NOT NULL,
  `booking_type` enum('regular','wedding','party') NOT NULL,
  `name` varchar(128) NOT NULL,
  `contact_number` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `package` varchar(32) NOT NULL,
  `booking_date` varchar(16) NOT NULL,
  `booking_time` varchar(16) NOT NULL,
  `groom_name` varchar(128) NOT NULL,
  `location` varchar(128) NOT NULL,
  `notes` varchar(256) NOT NULL,
  `payment` tinyint(1) NOT NULL,
  `status` enum('pending','approved','rejected','cancelled','completed') NOT NULL,
  `dob` date DEFAULT NULL,
  `nic` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_requests`
--

INSERT INTO `booking_requests` (`id`, `booking_type`, `name`, `contact_number`, `email`, `package`, `booking_date`, `booking_time`, `groom_name`, `location`, `notes`, `payment`, `status`, `dob`, `nic`, `address`) VALUES
(30, 'regular', 'prasha', '076254896', 'prasha@gmail.com', 'Facial', '2025-06-17T18:30', '1:00:00 AM', '', '', '', 1, 'completed', NULL, NULL, NULL),
(31, 'regular', 'piyumi', '0713689405', 'piyumi@gmail.com', 'Nail Art', '2025-06-18T18:30', '2:00:00 AM', '', '', '', 0, 'cancelled', NULL, NULL, NULL),
(32, 'regular', 'laxman', '075689526', 'laxman@gmail.com', 'Facial', '2025-06-16T18:30', '1:30:00 AM', '', '', '', 0, 'cancelled', NULL, NULL, NULL),
(33, 'regular', 'nimeshika', '0758969425', 'nime@gmail.com', 'Makeup', '2025-06-24T18:30', '2:00:00 AM', '', '', '', 1, 'completed', NULL, NULL, NULL),
(34, 'regular', 'chethana', '071893242', 'che@gmail.com', 'Facial', '2025-06-16T18:30', '1:30:00 AM', '', '', '', 1, 'completed', '2025-06-23', '200263802748', 'gelioya'),
(35, 'regular', 'laxman dassanayake', '07568947', 'lax@gmail.com', 'Facial', '2025-06-17T18:30', '12:30:00 AM', '', '', '', 0, 'approved', '2025-06-13', '111111111v', 'japan'),
(37, 'regular', 'RMPM Rathnayake', '0752365894', 'pra@gmail.com', 'Eyebrow Shaping', '2025-06-19T18:30', '1:30:00 AM', '', '', '', 0, 'cancelled', '2025-06-19', '200245678435', 'kandy'),
(38, 'regular', 'mashi', '0758963256', 'mashi@gmail.com', 'Hair Color', '2025-06-17T18:30', '1:00:00 AM', '', '', '', 1, 'pending', '2025-06-04', '2001234567', 'ampitiya'),
(39, 'regular', 'hiru', '0758962456', 'hiru@gmail.com', 'Facial', '', '', '', '', '', 0, 'pending', '0000-00-00', '', ''),
(40, 'regular', '', '', '', 'Eyebrow Shaping', '', '', '', '', '', 0, 'pending', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `contact_number` varchar(16) NOT NULL,
  `feedback` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `name`, `email`, `contact_number`, `feedback`) VALUES
(0, 'Akalanka Kavinda', 'ak.kavinda@gmail.com', '06633552728', 'good service'),
(0, 'nadee rathnayake', 'nadee@gmail.com', '0711724520', 'good job');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `package_type` varchar(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_referance` varchar(20) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `service` varchar(32) NOT NULL,
  `enabled` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service`, `enabled`) VALUES
(1, 'Haircut', 1),
(2, 'Facial', 1),
(3, 'Makeup', 1),
(4, 'Nail Art', 1),
(5, 'Hair Color', 1),
(6, 'Eyebrow Shaping', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_name`, `password`, `id`) VALUES
('prasha', '1234', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_requests`
--
ALTER TABLE `booking_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_requests`
--
ALTER TABLE `booking_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
